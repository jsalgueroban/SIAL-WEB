# Banasan UI

Libreria web de componentes React para interfaces SIAL.

## Instalacion

```bash
pnpm add @banasandev/banasan-ui
```

## Uso

```tsx
import { Button, TextInput } from "@banasandev/banasan-ui";
import "@banasandev/banasan-ui/style.css";

export function Example() {
  return (
    <form>
      <TextInput label="Nombre" placeholder="Nombre" />
      <Button type="submit">Guardar</Button>
    </form>
  );
}
```

## Alcance

Esta libreria publica componentes web. Los componentes moviles se manejaran en una libreria separada.

## Peer dependencies

El proyecto consumidor debe instalar React. React DOM y Recharts se declaran como peers opcionales segun los componentes usados.

## Desarrollo

```bash
pnpm install
pnpm dev
pnpm build
```

La documentacion local se levanta con `pnpm dev` y queda disponible en la URL que indique Vite.
