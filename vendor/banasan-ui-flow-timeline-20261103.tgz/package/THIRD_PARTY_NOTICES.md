# Third-party notices

## Font Awesome Free — broom icon

Author: Font Awesome / Fonticons, Inc.

Source: https://fontawesome.com/icons/broom

License for the icon artwork: Creative Commons Attribution 4.0 International (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/

The broom SVG path and viewBox (0 0 576 512) are copied without geometric modification from the existing SIAL Web proposal, where this attribution was already recorded. Packaging as BroomIcon / SialIcon name="broom" adds the library's size, color and accessibility API. The filled artwork is preserved.
