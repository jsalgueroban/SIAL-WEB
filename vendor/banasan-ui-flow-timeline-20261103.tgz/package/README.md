# Banasan UI

Libreria web de componentes React para interfaces SIAL.

## Instalacion

```bash
pnpm add @banasandev/banasan-ui
```

## Uso

```tsx
import { Button, TextInput } from "@banasandev/banasan-ui";
import "@banasandev/banasan-ui/style.css";

export function Example() {
  return (
    <form>
      <TextInput label="Nombre" placeholder="Nombre" />
      <Button type="submit">Guardar</Button>
    </form>
  );
}
```

## Alcance

Esta libreria publica componentes web. Los componentes moviles se manejaran en una libreria separada.

## Peer dependencies

El proyecto consumidor debe instalar React. React DOM y Recharts se declaran como peers opcionales segun los componentes usados.

## Desarrollo

```bash
pnpm install
pnpm dev
pnpm build
```

La documentacion local se levanta con `pnpm dev` y queda disponible en la URL que indique Vite.

## Variante navideña del isotipo SIAL

```tsx
import { SialIsotype } from "@banasandev/banasan-ui";
import "@banasandev/banasan-ui/style.css";

<SialIsotype size={64} title="SIAL" />
<SialIsotype variant="christmas" size={64} title="SIAL" />
<SialIsotype variant="christmas" motion="welcome" size={64} title="SIAL" />
<SialIsotype variant="christmas" motion="festive" size={44} title="SIAL" />
```

La variante predeterminada conserva el isotipo habitual. Navidad es optativa, sin
activación por fecha. `motion="none"` es el valor predeterminado; `welcome` reproduce
un único balanceo del gorro al montar el componente, durante 3,6 segundos. El logo y
el borde frontal permanecen fijos. Respeta `prefers-reduced-motion` y usa fondo
transparente. `size` conserva la misma escala, encuadre y alineación del símbolo
habitual. El gorro sobresale del SVG: reserva espacio superior (aproximadamente un
30 % de `size`) y lateral derecho (un 20 %), y evita `overflow: hidden` en sus
contenedores. Ese espacio adicional no reduce ni desplaza el isotipo.
Se muestra en la sección Icons del catálogo. No requiere recursos ni peticiones externas.

`motion="festive"` en Navidad repite un balanceo más visible cada 6 segundos:
2,76 segundos de gesto y 3,24 de reposo. Copa, punta y pompón permanecen unidos;
el símbolo y el borde blanco están fijos. Se desactiva con movimiento reducido.

## Variante de Año Nuevo

```tsx
<SialIsotype variant="new-year" size={64} title="SIAL" />
<SialIsotype variant="new-year" motion="welcome" size={64} title="SIAL" />
```

Gorro de fiesta azul y dorado con bandas y estrella. Conserva el tamaño y la
alineación del isotipo original. `welcome` activa un balanceo de 3,6 segundos y un
destello suave de la estrella, sin repetir; con movimiento reducido se muestra
estático. Reserva aproximadamente un 40 % de `size` sobre el símbolo para el gorro.
El selector Festividad del catálogo permite alternar con Navidad.
# Filtros con limpieza animada

`FilterToolbar` organiza campos controlados y la acción accesible de limpiar:

```tsx
<FilterToolbar active={Boolean(search || status)} onClear={clearFilters}>
  <TextInput key="search" value={search} onChange={setSearch} placeholder="Buscar" />
  <SelectInput key="status" value={status} onChange={setStatus} options={options} />
</FilterToolbar>
```

Cada hijo directo es un campo. La pantalla define valores y limpieza; la librería anima la redistribución y respeta movimiento reducido. `clearLabel` permite personalizar el nombre accesible. Véase `docs/filter-toolbar-promotion.md` y el catálogo `/toolbars`. Incorporación local, sin publicación de versión en esta entrega.

## Recorridos conectados

`FlowTimeline variant="connected"` conserva selección controlada y `reverseIndex`.
Cada item admite `timestamp={{dateTime, label}}`, `meta` y `markerLabel` separados de
la descripción. El consumidor define cuál evento es el último: cambiar `selectedKey`
no cambia esa etiqueta. Flechas, Home y End seleccionan y muestran el hito dentro
del scroll; respeta movimiento reducido. Altura máxima 480 px / 380 px en móvil,
personalizable con `maxHeight`. La variante predeterminada `cards` es compatible.
No introducir controles interactivos dentro de los campos de un hito (es un botón).
Ver catálogo `/audit` y `docs/flow-timeline-connected-promotion.md`.
